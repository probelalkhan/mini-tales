package dev.belalkhan.minitales.auth.validators

enum class AuthParams {
    FULL_NAME, EMAIL, PASSWORD, CONFIRM_PASSWORD
}
