package dev.belalkhan.minitales.storage

data class CurrentUser(
    val id: Int,
    val authKey: String,
)
