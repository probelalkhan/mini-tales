package dev.belalkhan.minitales.commons.domain.models

enum class ResourceError {
    UNAUTHORIZED,
    SERVICE_UNAVAILABLE,
    UNKNOWN,
}
