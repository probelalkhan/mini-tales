package dev.belalkhan.minitales.commons.utils

interface Mapper<F, T> {
    fun map(from: F): T
}
