package dev.belalkhan.minitales.commons.utils.validator

data class ValidationResult(
    val errorMessage: Int? = null,
) {
    val isValid: Boolean
        get() = errorMessage == null
}
