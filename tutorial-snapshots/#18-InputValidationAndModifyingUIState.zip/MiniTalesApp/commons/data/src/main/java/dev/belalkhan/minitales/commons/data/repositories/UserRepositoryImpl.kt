package dev.belalkhan.minitales.commons.data.repositories

import dev.belalkhan.minitales.commons.data.models.UserApiModel
import dev.belalkhan.minitales.network.NetworkResult
import dev.belalkhan.minitales.network.Response
import dev.belalkhan.minitales.network.RequestHandler
import javax.inject.Inject

private const val USER = "user"

class UserRepositoryImpl @Inject constructor(
    private val requestHandler: RequestHandler,
) : UserRepository {

    override suspend fun user(): NetworkResult<Response<UserApiModel>> =
        requestHandler.get(urlPathSegments = listOf(USER))
}
