package dev.belalkhan.minitales.commons.data.repositories

import dev.belalkhan.minitales.commons.data.models.UserApiModel
import dev.belalkhan.minitales.network.NetworkResult
import dev.belalkhan.minitales.network.Response

interface UserRepository {
    suspend fun user(): NetworkResult<Response<UserApiModel>>
}
