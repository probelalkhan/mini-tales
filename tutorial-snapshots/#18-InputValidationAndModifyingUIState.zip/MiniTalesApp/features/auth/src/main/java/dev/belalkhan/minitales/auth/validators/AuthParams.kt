package dev.belalkhan.minitales.auth.validators

enum class AuthParams {
    EMAIL, PASSWORD
}