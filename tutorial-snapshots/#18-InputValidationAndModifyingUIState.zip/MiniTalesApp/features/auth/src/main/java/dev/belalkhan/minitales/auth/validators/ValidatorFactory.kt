package dev.belalkhan.minitales.auth.validators

import dev.belalkhan.minitales.commons.utils.validator.InputValidator
import javax.inject.Inject

class ValidatorFactory @Inject constructor() {

    private val validators : Map<AuthParams, InputValidator> = mapOf(
        AuthParams.EMAIL to EmailValidator(),
        AuthParams.PASSWORD to PasswordValidator()
    )

    fun get(params: AuthParams) : InputValidator {
        return validators[params] ?: throw IllegalArgumentException("Invalid Parameter Provided")
    }
}