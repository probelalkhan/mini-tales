package dev.belalkhan.minitales.auth.validators

import dev.belalkhan.minitales.auth.R
import dev.belalkhan.minitales.commons.utils.validator.InputValidator
import dev.belalkhan.minitales.commons.utils.validator.ValidationResult

class EmailValidator : InputValidator {

    private val emailPattern = Regex(
        "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,}$",
        RegexOption.IGNORE_CASE,
    )

    override fun validate(input: String): ValidationResult {
        return if (input.isEmpty()) {
            ValidationResult(R.string.empty_email)
        } else if (emailPattern.matches(input).not()) {
            ValidationResult(R.string.invalid_email)
        } else {
            ValidationResult()
        }
    }
}