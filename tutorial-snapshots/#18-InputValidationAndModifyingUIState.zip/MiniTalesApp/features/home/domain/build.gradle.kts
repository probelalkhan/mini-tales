@Suppress("DSL_SCOPE_VIOLATION")
plugins {
    id("java-library")
    alias(libs.plugins.kotlin.jvm)
}

dependencies {
    implementation(projects.commons.data)
    implementation(projects.commons.domain)
    implementation(projects.commons.utils)
    implementation(projects.features.home.data)
    implementation(projects.network)
    implementation(libs.javax.inject)
}