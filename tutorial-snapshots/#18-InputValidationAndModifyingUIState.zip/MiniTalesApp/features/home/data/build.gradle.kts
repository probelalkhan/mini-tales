@Suppress("DSL_SCOPE_VIOLATION")
plugins {
    id("java-library")
    alias(libs.plugins.kotlin.jvm)
}

dependencies {
    implementation(projects.network)
    implementation(projects.commons.data)
    implementation(libs.ktor.serialization)
    implementation(libs.javax.inject)
}