package dev.belalkhan.minitales

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import dev.belalkhan.minitales.theme.MiniTalesTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MiniTalesTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Text("Hello Mini Tales")
                }
            }
        }
    }
}
