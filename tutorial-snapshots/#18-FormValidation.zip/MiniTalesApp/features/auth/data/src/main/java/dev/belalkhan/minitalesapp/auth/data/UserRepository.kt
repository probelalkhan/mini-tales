package dev.belalkhan.minitalesapp.auth.data

import dev.belalkhan.minitales.network.NetworkResult
import dev.belalkhan.minitales.network.Response

interface UserRepository {
    suspend fun user(): NetworkResult<Response<UserApiModel>>
}