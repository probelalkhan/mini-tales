package dev.belalkhan.minitales.auth.login

import androidx.annotation.StringRes

data class LoginUiState(
    val email: String = "",
    @StringRes val emailError: Int? = null,

    val password: String = "",
    @StringRes val passwordError: Int? = null
)
