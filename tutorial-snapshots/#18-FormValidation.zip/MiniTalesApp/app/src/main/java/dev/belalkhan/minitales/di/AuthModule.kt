package dev.belalkhan.minitales.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent
import dev.belalkhan.minitalesapp.auth.data.AuthRepository
import dev.belalkhan.minitalesapp.auth.data.AuthRepositoryImpl
import dev.belalkhan.minitalesapp.auth.data.UserRepository
import dev.belalkhan.minitalesapp.auth.data.UserRepositoryImpl

@InstallIn(ViewModelComponent::class)
@Module
class AuthModule {

    @Provides
    fun provideAuthRepository(impl: AuthRepositoryImpl): AuthRepository = impl

    @Provides
    fun provideUserRepository(impl: UserRepositoryImpl): UserRepository = impl
}