package dev.belalkhan.minitales.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dev.belalkhan.minitales.BuildConfig
import dev.belalkhan.minitales.DataStoreSessionHandler
import dev.belalkhan.minitales.network.MiniTalesHttpClientBuilder
import dev.belalkhan.minitales.network.RequestHandler
import dev.belalkhan.minitales.storage.SessionHandler
import io.ktor.client.HttpClient
import io.ktor.http.URLProtocol

@Module
@InstallIn(SingletonComponent::class)
class NetworkModule {

    @Provides
    fun provideSessionHandler(dataStoreSessionHandler: DataStoreSessionHandler): SessionHandler = dataStoreSessionHandler

    @Provides
    fun provideHttpClient(sessionHandler: SessionHandler): HttpClient =
        MiniTalesHttpClientBuilder(sessionHandler)
            .protocol(URLProtocol.HTTP)
            .host(BuildConfig.MINI_TALES_HOST)
            .port(8080)
            .build()

    @Provides
    fun provideRequestHandler(client: HttpClient): RequestHandler = RequestHandler(client)

}