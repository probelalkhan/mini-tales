package dev.belalkhan.minitales

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MiniTalesApp : Application()