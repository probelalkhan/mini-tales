package dev.belalkhan.minitales.auth.login

data class LoginUiState(
    val email: String = "",
    val password: String = ""
)
