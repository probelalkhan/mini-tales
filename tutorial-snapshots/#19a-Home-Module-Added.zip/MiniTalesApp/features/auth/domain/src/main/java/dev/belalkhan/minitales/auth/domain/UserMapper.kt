package dev.belalkhan.minitales.auth.domain

import dev.belalkhan.minitales.common.data.models.UserApiModel
import dev.belalkhan.minitales.common.utils.Mapper
import javax.inject.Inject

class UserMapper @Inject constructor() : Mapper<UserApiModel, User> {
    override fun map(from: UserApiModel): User {
        return User(
            avatar = from.avatar,
            email = from.email,
            createdAt = from.createdAt,
            fullName = from.fullName,
            id = from.id,
        )
    }
}