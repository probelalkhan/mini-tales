package dev.belalkhan.minitales.auth.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dev.belalkhan.minitales.auth.domain.LoginUseCase
import dev.belalkhan.minitales.auth.validators.AuthParam
import dev.belalkhan.minitales.auth.validators.ValidatorFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val loginUseCase: LoginUseCase,
    private val validatorFactory: ValidatorFactory,
) : ViewModel() {

    private val _uiState = MutableStateFlow(LoginUiState())
    val uiState: StateFlow<LoginUiState> = _uiState

    fun onEvent(uiEvent: LoginUiEvent) {
        when (uiEvent) {
            is LoginUiEvent.EmailChanged -> {
                _uiState.value = _uiState.value.copy(email = uiEvent.email)
            }

            is LoginUiEvent.PasswordChanged -> {
                _uiState.value = _uiState.value.copy(password = uiEvent.password)
            }

            is LoginUiEvent.Login -> {
                if(areInputsValid()) {
                    login()
                }
            }

            else -> {

            }
        }
    }

    private fun areInputsValid(): Boolean{
        val email = uiState.value.email
        val password = uiState.value.password
        val emailError = validatorFactory.get(AuthParam.EMAIL).validate(email)
        val passwordError = validatorFactory.get(AuthParam.PASSWORD).validate(password)

        _uiState.value = _uiState.value.copy(emailError = emailError.errorMessage, passwordError = passwordError.errorMessage)

        val hasError = listOf(emailError, passwordError).any { it.isValid.not() }
        return hasError.not()
    }

    fun login() = viewModelScope.launch {
        loginUseCase.invoke(_uiState.value.email, _uiState.value.password)
    }
}