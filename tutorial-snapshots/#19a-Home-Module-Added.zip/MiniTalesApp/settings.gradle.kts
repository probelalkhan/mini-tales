pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "MiniTales"

enableFeaturePreview("TYPESAFE_PROJECT_ACCESSORS")
include(":app")
include(":theme")
include(":network")
include(":common")
include(":common:data")
include(":common:domain")
include(":common:utils")
include(":features:auth")
include(":features:auth:data")
include(":features:auth:domain")
include(":features:home")
include(":features:home:data")
include(":features:home:domain")
include(":storage")
