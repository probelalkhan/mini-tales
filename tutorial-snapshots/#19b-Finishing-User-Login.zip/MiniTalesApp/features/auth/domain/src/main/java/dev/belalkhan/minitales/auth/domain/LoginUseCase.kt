package dev.belalkhan.minitales.auth.domain

import dev.belalkhan.minitales.network.NetworkException
import dev.belalkhan.minitales.network.NetworkResult
import dev.belalkhan.minitales.storage.SessionHandler
import dev.belalkhan.minitalesapp.auth.data.AuthRepository
import dev.belalkhan.minitalesapp.auth.data.UserLoginRequest
import javax.inject.Inject

class LoginUseCase @Inject constructor(
    private val repository: AuthRepository,
    private val sessionHandler: SessionHandler,
    private val mapper: UserMapper
) {

    suspend fun invoke(email: String, password: String): Resource<User> {
        val request = UserLoginRequest(email, password)
        return when(val result = repository.login(request)){
            is NetworkResult.Error -> result.toResourceError()
            is NetworkResult.Success -> {
                sessionHandler.setCurrentUser(result.result.data.id, result.result.data.authToken)
                Resource.Success(mapper.map(result.result.data))
            }
        }
    }
}

fun NetworkResult.Error<*>.toResourceError(): Resource.Error {
    return when (exception) {
        is NetworkException.NotFoundException -> Resource.Error(ResourceError.SERVICE_UNAVAILABLE)
        is NetworkException.UnauthorizedException -> Resource.Error(ResourceError.UNAUTHORIZED)
        is NetworkException.UnknownException ->  Resource.Error(ResourceError.UNKNOWN)
    }
}