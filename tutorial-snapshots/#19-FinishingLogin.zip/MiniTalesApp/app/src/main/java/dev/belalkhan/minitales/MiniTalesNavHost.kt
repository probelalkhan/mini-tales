package dev.belalkhan.minitales

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import dev.belalkhan.minitales.auth.authNavGraph
import dev.belalkhan.minitales.auth.authRoute
import dev.belalkhan.minitales.home.HomeScreen
import dev.belalkhan.minitales.home.homeRoute

@Composable
fun MiniTalesNavHost(navHostController: NavHostController) {
    NavHost(
        navController = navHostController,
        startDestination = authRoute,
    ) {
        authNavGraph(
            navController = navHostController,
            onAuthSuccess = {
                  navHostController.navigate(homeRoute){
                      popUpTo(authRoute) {
                          inclusive = true
                      }
                  }
            },
        )

        composable(homeRoute){
            HomeScreen(onLogout = { /*TODO*/ }, onWriteStory = { /*TODO*/ }) {
                
            }
        }
    }
}
