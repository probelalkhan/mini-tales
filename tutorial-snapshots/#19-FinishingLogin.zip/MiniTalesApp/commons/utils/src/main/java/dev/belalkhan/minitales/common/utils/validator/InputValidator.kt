package dev.belalkhan.minitales.commons.utils.validator

interface InputValidator {
    fun validate(input: String): ValidationResult
}
