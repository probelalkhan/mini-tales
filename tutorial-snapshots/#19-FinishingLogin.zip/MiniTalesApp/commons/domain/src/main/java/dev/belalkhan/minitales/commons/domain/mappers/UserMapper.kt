package dev.belalkhan.minitales.commons.domain.mappers

import dev.belalkhan.minitales.commons.data.models.UserApiModel
import dev.belalkhan.minitales.commons.domain.models.User
import dev.belalkhan.minitales.commons.utils.Mapper
import javax.inject.Inject

class UserMapper @Inject constructor() : Mapper<UserApiModel, User> {
    override fun map(from: UserApiModel): User =
        User(
            avatar = from.avatar,
            email = from.email,
            createdAt = from.createdAt,
            fullName = from.fullName,
            id = from.id,
        )
}
