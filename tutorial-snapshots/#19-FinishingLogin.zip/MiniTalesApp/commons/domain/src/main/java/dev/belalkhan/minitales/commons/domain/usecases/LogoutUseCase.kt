package dev.belalkhan.minitales.commons.domain.usecases

import dev.belalkhan.minitales.storage.SessionHandler
import javax.inject.Inject

class LogoutUseCase @Inject constructor(
    private val sessionHandler: SessionHandler,
) {
    suspend fun invoke() {
        sessionHandler.clear()
    }
}
