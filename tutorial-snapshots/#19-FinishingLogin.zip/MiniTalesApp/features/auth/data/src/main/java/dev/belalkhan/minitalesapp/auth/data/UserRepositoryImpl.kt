package dev.belalkhan.minitalesapp.auth.data

import dev.belalkhan.minitales.network.NetworkResult
import dev.belalkhan.minitales.network.RequestHandler
import dev.belalkhan.minitales.network.Response
import javax.inject.Inject

class UserRepositoryImpl @Inject constructor(
    private val requestHandler: RequestHandler
) : UserRepository {

    override suspend fun user(): NetworkResult<Response<UserApiModel>> =
        requestHandler.get(urlPathSegments = listOf("user"))

}